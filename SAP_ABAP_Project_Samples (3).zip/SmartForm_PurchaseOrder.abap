* Go to transaction SMARTFORMS and create ZSMARTFORM_PO
* This ABAP program just calls it.

REPORT ZCALL_SMARTFORM.

DATA: fm_name TYPE rs38l_fnam.

CALL FUNCTION 'SSF_FUNCTION_MODULE_NAME'
  EXPORTING
    formname           = 'ZSMARTFORM_PO'
  IMPORTING
    fm_name            = fm_name.

CALL FUNCTION fm_name
  EXPORTING
    control_parameters = value #( preview = 'X' )
    output_options     = value #( )
    user_settings      = 'X'.