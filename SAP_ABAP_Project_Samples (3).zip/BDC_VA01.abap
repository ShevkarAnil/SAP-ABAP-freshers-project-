REPORT ZBDC_SALES_ORDER_UPLOAD.

TABLES: VBAK, VBAP.

DATA: BEGIN OF it_data OCCURS 0,
        vbeln TYPE vbak-vbeln,
        posnr TYPE vbap-posnr,
        matnr TYPE vbap-matnr,
        kwmeng TYPE vbap-kwmeng,
      END OF it_data.

START-OF-SELECTION.
  PERFORM upload_data.
  PERFORM call_transaction.

FORM upload_data.
* Here, you'd typically read from a file using GUI_UPLOAD
* Hardcoded example:
  it_data-vbeln = '1000001'.
  it_data-posnr = '10'.
  it_data-matnr = 'MAT001'.
  it_data-kwmeng = '5'.
  APPEND it_data.
ENDFORM.

FORM call_transaction.
  LOOP AT it_data.
    CALL TRANSACTION 'VA01' USING bdcdata
    MODE 'N'.
  ENDLOOP.
ENDFORM.