REPORT ZALV_SALES_ORDER.

TABLES: VBAK.

TYPES: BEGIN OF ty_vbak,
         vbeln TYPE vbak-vbeln,
         erdat TYPE vbak-erdat,
         ernam TYPE vbak-ernam,
       END OF ty_vbak.

DATA: it_vbak TYPE TABLE OF ty_vbak,
      wa_vbak TYPE ty_vbak.

SELECT vbeln erdat ernam FROM vbak INTO TABLE it_vbak UP TO 100 ROWS.

CALL FUNCTION 'REUSE_ALV_GRID_DISPLAY'
  EXPORTING
    i_structure_name = 'TY_VBAK'
  TABLES
    t_outtab = it_vbak.